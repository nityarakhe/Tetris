# Panda

This project was made for university evlauation. 
This is project is not curently finished.

This project is a version of Tetris meant to be played against an AI agent


Thank you :)
